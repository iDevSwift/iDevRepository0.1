import UIKit
// Una palabra reservada es una palabra que tiene una funcionalidad propia. (Morado)

/*
 import | Es una palabra usada para importar librerias <Una librerias es una coleccion de lineas de codigo>
 var | Ayuda a crear variables
 ...etc */


