import UIKit

//VARIABLES

/*
 en este espacio se puede escribir
 sin que la prueba vea este codigo o notas
 */
var myFirstVariable = "Hola Mundo" // <- Con estas barras podemos comentar al lado, una linea entera o hacer pequeñas anotaciones
var myFirstNumberVariable = 1

print(myFirstVariable) //Para "imprimir" esa palabra en la ventana de comandos, si no, en Swift aparece a la derecha el resultado (por ejemplo, de una suma).

myFirstVariable = "Esta es la variable de la 1 variable"
print(myFirstVariable)
/*myFirstVariable = 1
 No podemos asignar un tipo Int a una variable tipo String. Para entendernos, no podemos asignar el valor que nos dé la gana, cada variable tiene que ir con su valor "real". Si hacemos esto, nos dará ERROR.
 */
var mySecondVariable = "Esta es la segunda variable"
print(mySecondVariable)
mySecondVariable = "Esta es la variable de la 2 variable"
print(mySecondVariable)

// Ahora, vamos a darle el valor a la FirstVariable de la ÚLTIMA cosa que hemos comentado en la SecondVariable. Seria tal que asi:
        myFirstVariable = mySecondVariable
print(mySecondVariable)

//Si intentamos cambiar la FirstVariable ahora, veremos que no surje ningún efecto ya que ha quedado con la antigua variable:
        myFirstVariable = "Ahora se cambia?"
print(mySecondVariable)
//Como se ve en la consola de comando, no ha surjido ningún cambio respecto a la linea 22

/*
 Para realizar varias declaraciones de lineas de variables ó de constantes, con separarlas por coma, se pueden generar múltiples declaraciones de variables en una sola linea y de hasta distintos tipos (letras y numeros). Por ej:
 var myFirstVariable = "Hola mundo", mySecondVariable = "Esta es la segunda variable",myThirdVariable = "Esta es la tercera variable"...asi constantemente hasta finalizar linea. */

//CONSTANTES
/*
 Para entendernos, esto es un valor FIJO que se asigna y no cambia como las variables. Como su propio nombre indica, las variables cambian constantemente pero las constantes son datos que siempre prevalecen.
 */

let myFirstConstant = "Has aprendido algo?"
print(myFirstConstant)
/* myFirstConstant = "Veamos cuanto aprendes sin saber que pasa"
Una constante no puede cambiar su valor. En la linea de abajo se muestra un cambio como en las variables, pero al ejecutarlo nos sale un ERROR y nos indica que debemos de ponerlo únicamente como "Has aprendido algo?"
 */

let mySecondConstant = myFirstVariable // Con este argumento, establecemos que la constante es el valor de la última vez que se ha escrito myFirstVariable = "x"
print(mySecondConstant)


